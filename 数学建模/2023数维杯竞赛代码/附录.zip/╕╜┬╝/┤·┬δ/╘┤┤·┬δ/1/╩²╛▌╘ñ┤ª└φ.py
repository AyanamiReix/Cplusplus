import pandas as pd
from tabulate import tabulate

# 定义数据
data = {
    "Tar yield": [18.06	,13.77	,11.29	,10.28,	9.49	,9.02	,10.3	,8.19],
    "Water yield": [15.3,18.54,	20.17	,20.97	,21.53	,21.87	,21.41	,23.69],
    "Char yield": [58.17,	57.46	,57.13,	56.98,	57.14,	57.23	,57.15	,57.43],
    "Syngas yield": [8.47,10.23,11.41,11.77,11.84,11.88,11.14,10.69]
}

# 创建DataFrame
df = pd.DataFrame(data)

# 计算统计指标
statistics = df.agg(['count', 'max', 'min', 'mean', 'std', 'median', 'var', 'kurt', 'skew']).T

# 计算变异系数，CV = (标准偏差 / 平均值) * 100
statistics['CV'] = (statistics['std'] / statistics['mean']) * 100

# 打印表格
print(tabulate(statistics, headers='keys', tablefmt='grid', numalign="right", floatfmt=".2f"))
