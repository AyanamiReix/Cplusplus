% 数据集
DFA_CS = [0, 10, 20, 30, 40, 50, 60, 80, 100]';

Tar_yield = [19.46, 17.25, 15.43, 14.14, 13.89, 13.21, 12.84, 12.57, 12.13]';
Water_yield = [26.84, 27.64, 28.11, 28.23, 28.62, 29.01, 30.07, 30.68, 31.02]';
Char_yield = [29.21, 29.11, 29.3, 29.34, 29.14, 29.33, 29.47, 29.64, 29.87]';
Syngas_yield = [24.49, 26, 27.16, 28.29, 28.35, 28.45, 27.62, 27.11, 26.98]';

% 初始化模型
mdl_tar_linear = cell(length(DFA_CS), 1);
mdl_tar_quad = cell(length(DFA_CS), 1);
mdl_tar_cubic = cell(length(DFA_CS), 1);
tar_pred_linear = zeros(length(DFA_CS), 1);
tar_pred_quad = zeros(length(DFA_CS), 1);
tar_pred_cubic = zeros(length(DFA_CS), 1);

mdl_tar_linear = cell(length(DFA_CS), 1);
mdl_tar_quad = cell(length(DFA_CS), 1);
mdl_tar_cubic = cell(length(DFA_CS), 1);
tar_pred_linear = zeros(length(DFA_CS), 1);
tar_pred_quad = zeros(length(DFA_CS), 1);
tar_pred_cubic = zeros(length(DFA_CS), 1);


mdl_water_linear = cell(length(DFA_CS), 1);
mdl_water_quad = cell(length(DFA_CS), 1);
mdl_water_cubic = cell(length(DFA_CS), 1);
water_pred_linear = zeros(length(DFA_CS), 1);
water_pred_quad = zeros(length(DFA_CS), 1);
water_pred_cubic = zeros(length(DFA_CS), 1);

mdl_char_linear = cell(length(DFA_CS), 1);
mdl_char_quad = cell(length(DFA_CS), 1);
mdl_char_cubic = cell(length(DFA_CS), 1);
char_pred_linear = zeros(length(DFA_CS), 1);
char_pred_quad = zeros(length(DFA_CS), 1);
char_pred_cubic = zeros(length(DFA_CS), 1);

mdl_syngas_linear = cell(length(DFA_CS), 1);
mdl_syngas_quad = cell(length(DFA_CS), 1);
mdl_syngas_cubic = cell(length(DFA_CS), 1);
syngas_pred_linear = zeros(length(DFA_CS), 1);
syngas_pred_quad = zeros(length(DFA_CS), 1);
syngas_pred_cubic = zeros(length(DFA_CS), 1);

% 循环遍历每个点作为对照点
for i = 1:length(DFA_CS)
    % 选择当前点作为对照点的数据
    reference_DFA_CS = DFA_CS(i);
    reference_Tar_yield = Tar_yield(i);
    reference_DFA_CS = DFA_CS(i);
    reference_Water_yield = Water_yield(i);
    reference_Char_yield = Char_yield(i);
    reference_Syngas_yield = Syngas_yield(i);
    
    % 从数据集中移除当前点
     DFA_CS_without_reference = DFA_CS([1:i-1, i+1:end]);
    Tar_yield_without_reference = Tar_yield([1:i-1, i+1:end]);
    DFA_CS_without_reference = DFA_CS([1:i-1, i+1:end]);
    Water_yield_without_reference = Water_yield([1:i-1, i+1:end]);
    Char_yield_without_reference = Char_yield([1:i-1, i+1:end]);
    Syngas_yield_without_reference = Syngas_yield([1:i-1, i+1:end]);
    
    % 构建1元、2元和3元线性回归模型
    mdl_tar_linear{i} = fitlm(DFA_CS_without_reference, Tar_yield_without_reference);
    mdl_tar_quad{i} = fitlm([DFA_CS_without_reference, DFA_CS_without_reference.^2], Tar_yield_without_reference);
    mdl_tar_cubic{i} = fitlm([DFA_CS_without_reference, DFA_CS_without_reference.^2, DFA_CS_without_reference.^3], Tar_yield_without_reference);
    
    mdl_water_linear{i} = fitlm(DFA_CS_without_reference, Water_yield_without_reference);
    mdl_water_quad{i} = fitlm([DFA_CS_without_reference, DFA_CS_without_reference.^2], Water_yield_without_reference);
    mdl_water_cubic{i} = fitlm([DFA_CS_without_reference, DFA_CS_without_reference.^2, DFA_CS_without_reference.^3], Water_yield_without_reference);
    
    mdl_char_linear{i} = fitlm(DFA_CS_without_reference, Char_yield_without_reference);
    mdl_char_quad{i} = fitlm([DFA_CS_without_reference, DFA_CS_without_reference.^2], Char_yield_without_reference);
    mdl_char_cubic{i} = fitlm([DFA_CS_without_reference, DFA_CS_without_reference.^2, DFA_CS_without_reference.^3], Char_yield_without_reference);
    
    mdl_syngas_linear{i} = fitlm(DFA_CS_without_reference, Syngas_yield_without_reference);
    mdl_syngas_quad{i} = fitlm([DFA_CS_without_reference, DFA_CS_without_reference.^2], Syngas_yield_without_reference);
    mdl_syngas_cubic{i} = fitlm([DFA_CS_without_reference, DFA_CS_without_reference.^2, DFA_CS_without_reference.^3], Syngas_yield_without_reference);
    
    % 计算每个模型的预测值
    tar_pred_linear(i) = predict(mdl_tar_linear{i}, reference_DFA_CS);
    tar_pred_quad(i) = predict(mdl_tar_quad{i}, [reference_DFA_CS, reference_DFA_CS^2]);
    tar_pred_cubic(i) = predict(mdl_tar_cubic{i}, [reference_DFA_CS, reference_DFA_CS^2, reference_DFA_CS^3]);
    water_pred_linear(i) = predict(mdl_water_linear{i}, reference_DFA_CS);
    water_pred_quad(i) = predict(mdl_water_quad{i}, [reference_DFA_CS, reference_DFA_CS^2]);
    water_pred_cubic(i) = predict(mdl_water_cubic{i}, [reference_DFA_CS, reference_DFA_CS^2, reference_DFA_CS^3]);
    
    char_pred_linear(i) = predict(mdl_char_linear{i}, reference_DFA_CS);
    char_pred_quad(i) = predict(mdl_char_quad{i}, [reference_DFA_CS, reference_DFA_CS^2]);
    char_pred_cubic(i) = predict(mdl_char_cubic{i}, [reference_DFA_CS, reference_DFA_CS^2, reference_DFA_CS^3]);
    
    syngas_pred_linear(i) = predict(mdl_syngas_linear{i}, reference_DFA_CS);
    syngas_pred_quad(i) = predict(mdl_syngas_quad{i}, [reference_DFA_CS, reference_DFA_CS^2]);
    syngas_pred_cubic(i) = predict(mdl_syngas_cubic{i}, [reference_DFA_CS, reference_DFA_CS^2, reference_DFA_CS^3]);
    
    % 输出实际值和预测值
    fprintf('Reference Point %d: DFA_CS=%.2f\n', i, reference_DFA_CS);
    fprintf('Tar Yield Actual: %.2f\n', reference_Tar_yield);
    
    fprintf('Linear Model Tar Yield Predicted: %.2f\n', tar_pred_linear(i));
    fprintf('Quadratic Model Tar Yield Predicted: %.2f\n', tar_pred_quad(i));
    
    fprintf('Reference Point %d: DFA_CS=%.2f\n', i, reference_DFA_CS);
    fprintf('Water Yield Actual: %.2f\n', reference_Water_yield);
    fprintf('Char Yield Actual: %.2f\n', reference_Char_yield);
    fprintf('Syngas Yield Actual: %.2f\n', reference_Syngas_yield);
    
    fprintf('Linear Model Water Yield Predicted: %.2f\n', water_pred_linear(i));
    fprintf('Quadratic Model Water Yield Predicted: %.2f\n', water_pred_quad(i));
    fprintf('Cubic Model Water Yield Predicted: %.2f\n', water_pred_cubic(i));
    
    fprintf('Linear Model Char Yield Predicted: %.2f\n', char_pred_linear(i));
    fprintf('Quadratic Model Char Yield Predicted: %.2f\n', char_pred_quad(i));
    fprintf('Cubic Model Char Yield Predicted: %.2f\n', char_pred_cubic(i));
    
    fprintf('Linear Model Syngas Yield Predicted: %.2f\n', syngas_pred_linear(i));
    fprintf('Quadratic Model Syngas Yield Predicted: %.2f\n', syngas_pred_quad(i));
    fprintf('Cubic Model Syngas Yield Predicted: %.2f\n', syngas_pred_cubic(i));
    
    fprintf('-----------------------------------------\n');
end








% 创建一个新的图形窗口
figure;

% 绘制线性模型的散点图
subplot(3, 1, 1);
scatter(DFA_CS, Tar_yield, 'b', 'filled', 'DisplayName', 'Actual');
hold on;
scatter(DFA_CS, tar_pred_linear, 'r', 'filled', 'DisplayName', 'Linear Predicted');
xlabel('DFA_CS');
ylabel('Tar Yield');
title('Linear Model');
legend('show');

% 绘制二次模型的散点图
subplot(3, 1, 2);
scatter(DFA_CS, Tar_yield, 'b', 'filled', 'DisplayName', 'Actual');
hold on;
scatter(DFA_CS, tar_pred_quad, 'g', 'filled', 'DisplayName', 'Quadratic Predicted');
xlabel('DFA_CS');
ylabel('Tar Yield');
title('Quadratic Model');
legend('show');

% 绘制三次模型的散点图
subplot(3, 1, 3);
scatter(DFA_CS, Tar_yield, 'b', 'filled', 'DisplayName', 'Actual');
hold on;
scatter(DFA_CS, tar_pred_cubic, 'm', 'filled', 'DisplayName', 'Cubic Predicted');
xlabel('DFA_CS');
ylabel('Tar Yield');
title('Cubic Model');
legend('show');

% 调整图形窗口布局
sgtitle('Tar Yield Prediction vs. Actual');

% 创建一个新的图形窗口
figure;

% 绘制线性模型的散点图
subplot(3, 1, 1);
scatter(DFA_CS, Water_yield, 'b', 'filled', 'DisplayName', 'Actual');
hold on;
scatter(DFA_CS, water_pred_linear, 'r', 'filled', 'DisplayName', 'Linear Predicted');
xlabel('DFA_CS');
ylabel('Water Yield');
title('Linear Model');
legend('show');

% 绘制二次模型的散点图
subplot(3, 1, 2);
scatter(DFA_CS, Water_yield, 'b', 'filled', 'DisplayName', 'Actual');
hold on;
scatter(DFA_CS, water_pred_quad, 'g', 'filled', 'DisplayName', 'Quadratic Predicted');
xlabel('DFA_CS');
ylabel('Water Yield');
title('Quadratic Model');
legend('show');

% 绘制三次模型的散点图
subplot(3, 1, 3);
scatter(DFA_CS, Water_yield, 'b', 'filled', 'DisplayName', 'Actual');
hold on;
scatter(DFA_CS, water_pred_cubic, 'm', 'filled', 'DisplayName', 'Cubic Predicted');
xlabel('DFA_CS');
ylabel('Water Yield');
title('Cubic Model');
legend('show');

% 调整图形窗口布局
sgtitle('Water Yield Prediction vs. Actual');

% 创建一个新的图形窗口
figure;

% 绘制线性模型的散点图
subplot(3, 1, 1);
scatter(DFA_CS, Char_yield, 'b', 'filled', 'DisplayName', 'Actual');
hold on;
scatter(DFA_CS, char_pred_linear, 'r', 'filled', 'DisplayName', 'Linear Predicted');
xlabel('DFA_CS');
ylabel('Char Yield');
title('Linear Model');
legend('show');

% 绘制二次模型的散点图
subplot(3, 1, 2);
scatter(DFA_CS, Char_yield, 'b', 'filled', 'DisplayName', 'Actual');
hold on;
scatter(DFA_CS, char_pred_quad, 'g', 'filled', 'DisplayName', 'Quadratic Predicted');
xlabel('DFA_CS');
ylabel('Char Yield');
title('Quadratic Model');
legend('show');

% 绘制三次模型的散点图
subplot(3, 1, 3);
scatter(DFA_CS, Char_yield, 'b', 'filled', 'DisplayName', 'Actual');
hold on;
scatter(DFA_CS, char_pred_cubic, 'm', 'filled', 'DisplayName', 'Cubic Predicted');
xlabel('DFA_CS');
ylabel('Char Yield');
title('Cubic Model');
legend('show');

% 调整图形窗口布局
sgtitle('Char Yield Prediction vs. Actual');

% 创建一个新的图形窗口
figure;

% 绘制线性模型的散点图
subplot(3, 1, 1);
scatter(DFA_CS, Syngas_yield, 'b', 'filled', 'DisplayName', 'Actual');
hold on;
scatter(DFA_CS, syngas_pred_linear, 'r', 'filled', 'DisplayName', 'Linear Predicted');
xlabel('DFA_CS');
ylabel('Syngas Yield');
title('Linear Model');
legend('show');

% 绘制二次模型的散点图
subplot(3, 1, 2);
scatter(DFA_CS, Syngas_yield, 'b', 'filled', 'DisplayName', 'Actual');
hold on;
scatter(DFA_CS, syngas_pred_quad, 'g', 'filled', 'DisplayName', 'Quadratic Predicted');
xlabel('DFA_CS');
ylabel('Syngas Yield');
title('Quadratic Model');
legend('show');

% 绘制三次模型的散点图
subplot(3, 1, 3);
scatter(DFA_CS, Syngas_yield, 'b', 'filled', 'DisplayName', 'Actual');
hold on;
scatter(DFA_CS, syngas_pred_cubic, 'm', 'filled', 'DisplayName', 'Cubic Predicted');
xlabel('DFA_CS');
ylabel('Syngas Yield');
title('Cubic Model');
legend('show');

% 调整图形窗口布局
sgtitle('Syngas Yield Prediction vs. Actual');