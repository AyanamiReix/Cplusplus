% Data
DFA_CS = [0, 10, 20, 30, 40, 50, 60, 80]';
Tar_yield = [19.46, 17.25, 15.43, 14.14, 13.89, 13.21, 12.84, 12.57]';
Water_yield = [26.84, 27.64, 28.11, 28.23, 28.62, 29.01, 30.07, 30.68]';
Char_yield = [29.21, 29.11, 29.3, 29.34, 29.14, 29.33, 29.47, 29.64]';
Syngas_yield = [24.49, 26, 27.16, 28.29, 28.35, 28.45, 27.62, 27.11]';

% Test data (the last point)
DFA_CS_test = [100]';
Tar_yield_test = [12.13]';
Water_yield_test = [31.02]';
Char_yield_test = [29.87]';
Syngas_yield_test = [26.98]';

% Linear Regression Models
mdl_tar_linear = fitlm(DFA_CS, Tar_yield);
mdl_water_linear = fitlm(DFA_CS, Water_yield);
mdl_char_linear = fitlm(DFA_CS, Char_yield);
mdl_syngas_linear = fitlm(DFA_CS, Syngas_yield);

% Quadratic Regression Models
DFA_CS_squared = DFA_CS .^ 2;
mdl_tar_quad = fitlm([DFA_CS, DFA_CS_squared], Tar_yield);
mdl_water_quad = fitlm([DFA_CS, DFA_CS_squared], Water_yield);
mdl_char_quad = fitlm([DFA_CS, DFA_CS_squared], Char_yield);
mdl_syngas_quad = fitlm([DFA_CS, DFA_CS_squared], Syngas_yield);

% Predictions
tar_pred_linear = predict(mdl_tar_linear, DFA_CS_test);
water_pred_linear = predict(mdl_water_linear, DFA_CS_test);
char_pred_linear = predict(mdl_char_linear, DFA_CS_test);
syngas_pred_linear = predict(mdl_syngas_linear, DFA_CS_test);

tar_pred_quad = predict(mdl_tar_quad, [DFA_CS_test, DFA_CS_test.^2]);
water_pred_quad = predict(mdl_water_quad, [DFA_CS_test, DFA_CS_test.^2]);
char_pred_quad = predict(mdl_char_quad, [DFA_CS_test, DFA_CS_test.^2]);
syngas_pred_quad = predict(mdl_syngas_quad, [DFA_CS_test, DFA_CS_test.^2]);

% Displaying the actual and predicted values for Tar Yield and Water Yield
fprintf('Tar Yield Actual: %.2f, Linear Predicted: %.2f, Quadratic Predicted: %.2f\n', Tar_yield_test, tar_pred_linear, tar_pred_quad);
fprintf('Water Yield Actual: %.2f, Linear Predicted: %.2f, Quadratic Predicted: %.2f\n', Water_yield_test, water_pred_linear, water_pred_quad);

% Cubic Regression Models
DFA_CS_cubed = DFA_CS .^ 3;
mdl_tar_cubic = fitlm([DFA_CS, DFA_CS_squared, DFA_CS_cubed], Tar_yield);
mdl_water_cubic = fitlm([DFA_CS, DFA_CS_squared, DFA_CS_cubed], Water_yield);
mdl_char_cubic = fitlm([DFA_CS, DFA_CS_squared, DFA_CS_cubed], Char_yield);
mdl_syngas_cubic = fitlm([DFA_CS, DFA_CS_squared, DFA_CS_cubed], Syngas_yield);

% Predictions for Cubic
tar_pred_cubic = predict(mdl_tar_cubic, [DFA_CS_test, DFA_CS_test.^2, DFA_CS_test.^3]);
water_pred_cubic = predict(mdl_water_cubic, [DFA_CS_test, DFA_CS_test.^2, DFA_CS_test.^3]);
char_pred_cubic = predict(mdl_char_cubic, [DFA_CS_test, DFA_CS_test.^2, DFA_CS_test.^3]);
syngas_pred_cubic = predict(mdl_syngas_cubic, [DFA_CS_test, DFA_CS_test.^2, DFA_CS_test.^3]);

% Displaying the cubic predicted values for Tar Yield and Water Yield
fprintf('Cubic Predicted Tar Yield: %.2f\n', tar_pred_cubic);
fprintf('Cubic Predicted Water Yield: %.2f\n', water_pred_cubic);

% Displaying the coefficients and residuals for linear, quadratic, and cubic models for Tar Yield
fprintf('Linear Model Tar Yield Coefficients:\n');
disp(mdl_tar_linear.Coefficients);
fprintf('Quadratic Model Tar Yield Coefficients:\n');
disp(mdl_tar_quad.Coefficients);
fprintf('Cubic Model Tar Yield Coefficients:\n');
disp(mdl_tar_cubic.Coefficients);

% Displaying the coefficients and residuals for linear, quadratic, and cubic models for Water Yield
fprintf('Linear Model Water Yield Coefficients:\n');
disp(mdl_water_linear.Coefficients);
fprintf('Quadratic Model Water Yield Coefficients:\n');
disp(mdl_water_quad.Coefficients);
fprintf('Cubic Model Water Yield Coefficients:\n');
disp(mdl_water_cubic.Coefficients);

% Repeat for Char Yield and Syngas Yield...
% Displaying the coefficients for Linear, Quadratic, and Cubic Models for Char Yield
fprintf('Linear Model Char Yield Coefficients:\n');
disp(mdl_char_linear.Coefficients);
fprintf('Quadratic Model Char Yield Coefficients:\n');
disp(mdl_char_quad.Coefficients);
fprintf('Cubic Model Char Yield Coefficients:\n');
disp(mdl_char_cubic.Coefficients);

% Displaying the coefficients for Linear, Quadratic, and Cubic Models for Syngas Yield
fprintf('Linear Model Syngas Yield Coefficients:\n');
disp(mdl_syngas_linear.Coefficients);
fprintf('Quadratic Model Syngas Yield Coefficients:\n');
disp(mdl_syngas_quad.Coefficients);
fprintf('Cubic Model Syngas Yield Coefficients:\n');
disp(mdl_syngas_cubic.Coefficients);


