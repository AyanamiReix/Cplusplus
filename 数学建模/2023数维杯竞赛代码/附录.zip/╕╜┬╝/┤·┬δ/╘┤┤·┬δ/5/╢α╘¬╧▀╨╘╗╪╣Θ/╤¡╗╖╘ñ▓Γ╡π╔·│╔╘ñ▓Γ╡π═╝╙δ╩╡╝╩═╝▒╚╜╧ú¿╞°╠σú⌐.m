
% 数据集
DFA_CS = [0, 0.20, 0.40, 0.50, 0.80, 1]';

% 每个组分的数据
H2 = [0.053892216, 0.102608834, 0.168928998, 0.215370423, 0.257065402, 0.284632953]';
CO = [0.215652029, 0.171358338, 0.153117542, 0.148665910, 0.149101999, 0.152169657]';
CO2 = [0.502328676, 0.458647213, 0.390140215, 0.368435992, 0.349237547, 0.332202284]';
CH4 = [0.194693945, 0.228292760, 0.246942124, 0.230272495, 0.208946120, 0.197128874]';
C2H6 = [0.017381903, 0.021647768, 0.022971360, 0.021217712, 0.020060996, 0.019184339]';
C3H8 = [0.004574185, 0.004837047, 0.004624105, 0.005038320, 0.005964080, 0.005676998]';
C3H6 = [0.002910845, 0.002933947, 0.003057876, 0.002767528, 0.002507625, 0.002479608]';
C2H4 = [0.005904857, 0.005867893, 0.006041169, 0.005606018, 0.005218570, 0.004893964]';
C4H10 = [0.002661344, 0.003806201, 0.004176611, 0.002625603, 0.001897662, 0.001631321]';
% 每个组分的数据
component_names = {'H2', 'CO', 'CO2', 'CH4', 'C2H6', 'C3H8', 'C3H6', 'C2H4', 'C4H10'};
component_data = [H2, CO, CO2, CH4, C2H6, C3H8, C3H6, C2H4, C4H10];

% 初始化模型和预测数组
mdl_linear = cell(length(component_names), 1);
mdl_quad = cell(length(component_names), 1);
mdl_cubic = cell(length(component_names), 1);
pred_linear = zeros(length(component_names), length(DFA_CS));
pred_quad = zeros(length(component_names), length(DFA_CS));
pred_cubic = zeros(length(component_names), length(DFA_CS));

% 循环遍历每个组分
for component_idx = 1:length(component_names)
    component_name = component_names{component_idx};
    component_data_values = component_data(:, component_idx);
    
    % 循环遍历每个点作为对照点
    for i = 1:length(DFA_CS)
        % 选择当前点作为对照点的数据
        reference_DFA_CS = DFA_CS(i);
        reference_component = component_data_values(i);
        
        % 从数据集中移除当前点
        DFA_CS_without_reference = DFA_CS([1:i-1, i+1:end]);
        component_without_reference = component_data_values([1:i-1, i+1:end]);
        
        % 构建1元、2元和3元线性回归模型
        mdl_linear{component_idx}{i} = fitlm(DFA_CS_without_reference, component_without_reference);
        mdl_quad{component_idx}{i} = fitlm([DFA_CS_without_reference, DFA_CS_without_reference.^2], component_without_reference);
        mdl_cubic{component_idx}{i} = fitlm([DFA_CS_without_reference, DFA_CS_without_reference.^2, DFA_CS_without_reference.^3], component_without_reference);
        
        % 计算每个模型的预测值
        pred_linear(component_idx, i) = predict(mdl_linear{component_idx}{i}, reference_DFA_CS);
        pred_quad(component_idx, i) = predict(mdl_quad{component_idx}{i}, [reference_DFA_CS, reference_DFA_CS^2]);
        pred_cubic(component_idx, i) = predict(mdl_cubic{component_idx}{i}, [reference_DFA_CS, reference_DFA_CS^2, reference_DFA_CS^3]);
        
        % 输出实际值和预测值
        fprintf('Component: %s, Reference Point %d: DFA_CS=%.2f\n', component_name, i, reference_DFA_CS);
        fprintf('%s Actual: %.6f\n', component_name, reference_component);
        fprintf('Linear Model %s Predicted: %.6f\n', component_name, pred_linear(component_idx, i));
        fprintf('Quadratic Model %s Predicted: %.6f\n', component_name, pred_quad(component_idx, i));
        fprintf('Cubic Model %s Predicted: %.6f\n', component_name, pred_cubic(component_idx, i));
        fprintf('-----------------------------------------\n');
    end
end

% ... 之前的代码 ...

% Create figures for visualization for each gas component (you can adapt this part)
% ... 之前的代码 ...

% Create figures for visualization for each gas component (you can adapt this part)
for component_idx = 1:length(component_names)
    component_name = component_names{component_idx};
    
    figure;
    set(gcf, 'Color', 'w'); % Set figure background color to white
    sgtitle(sprintf('%s Concentration Prediction vs. Actual', component_name));
    
    % Plot the actual and predicted values for each component using linear, quadratic, and cubic models
    subplot(3, 1, 1);
    scatter(DFA_CS, component_data(:, component_idx), 'b', 'filled', 'MarkerFaceAlpha', 0.6);
    hold on;
    scatter(DFA_CS, pred_linear(component_idx, :), 'r', 'filled', 'MarkerFaceAlpha', 0.6);
    xlabel('DFA_CS');
    ylabel(sprintf('%s Concentration', component_name));
    title('Linear Model');
    grid on; % Enable grid
    
    set(gca, 'FontSize', 7); % Set font size to 7 points
    set(gca, 'FontWeight', 'bold'); % Set font weight to bold
    set(gca, 'FontAngle', 'italic'); % Set font angle to italic
    set(gca, 'LineWidth', 0.8); % Set line width to 0.8 points

    subplot(3, 1, 2);
    scatter(DFA_CS, component_data(:, component_idx), 'b', 'filled', 'MarkerFaceAlpha', 0.6);
    hold on;
    scatter(DFA_CS, pred_quad(component_idx, :), 'g', 'filled', 'MarkerFaceAlpha', 0.6);
    xlabel('DFA_CS');
    ylabel(sprintf('%s Concentration', component_name));
    title('Quadratic Model');
    grid on; % Enable grid
    
    set(gca, 'FontSize', 7); % Set font size to 7 points
    set(gca, 'FontWeight', 'bold'); % Set font weight to bold
    set(gca, 'FontAngle', 'italic'); % Set font angle to italic
    set(gca, 'LineWidth', 0.8); % Set line width to 0.8 points

    subplot(3, 1, 3);
    scatter(DFA_CS, component_data(:, component_idx), 'b', 'filled', 'MarkerFaceAlpha', 0.6);
    hold on;
    scatter(DFA_CS, pred_cubic(component_idx, :), 'm', 'filled', 'MarkerFaceAlpha', 0.6);
    xlabel('DFA_CS');
    ylabel(sprintf('%s Concentration', component_name));
    title('Cubic Model');
    grid on; % Enable grid
    
    set(gca, 'FontSize', 7); % Set font size to 7 points
    set(gca, 'FontWeight', 'bold'); % Set font weight to bold
    set(gca, 'FontAngle', 'italic'); % Set font angle to italic
    set(gca, 'LineWidth', 0.8); % Set line width to 0.8 points
    
    % Remove legend
    legend('off');
    
    % Save the figure as a JPG file with an absolute path and 600 dpi resolution
    output_filename = fullfile('F:\建模比赛\图片\第五题\多元线性\气体', sprintf('%s_Concentration_Prediction.jpg', component_name));
    print(gcf, output_filename, '-djpeg', '-r600');
    
    % Close the figure
    close;
end
