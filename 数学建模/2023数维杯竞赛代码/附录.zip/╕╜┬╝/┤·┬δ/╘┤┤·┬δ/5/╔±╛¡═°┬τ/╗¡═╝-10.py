import matplotlib.pyplot as plt
import numpy as np
import os

# 共享的x轴数据
concentrations = np.array([0, 0.1, 0.20, 0.30, 0.40, 0.50, 0.60, 0.80, 1])

tar_yield = np.array([19.46, 17.25, 15.43, 14.14, 13.89, 13.21, 12.84, 12.57, 12.13])
water_yield = np.array([26.84, 27.64, 28.11, 28.23, 28.62, 29.01, 30.07, 30.68, 31.02])
char_yield = np.array([29.21, 29.11, 29.3, 29.34, 29.14, 29.33, 29.47, 29.64, 29.87])
syngas_yield = np.array([24.49, 26, 27.16, 28.29, 28.35, 28.45, 27.62, 27.11, 26.98])

# 预测结果数据 - 10
predicted_results_10 = np.array([
    [19.342688, 26.952856, 29.170204, 24.528713],
    [17.420567, 27.504332, 29.198965, 25.86651],
    [15.431162, 28.024368, 29.254776, 27.297169],
    [14.095556, 28.391962, 29.267443, 28.274456],
    [13.933967, 28.493618, 29.227776, 28.362648],
    [13.134107, 29.121588, 29.32278, 28.343155],
    [12.818605, 30.071901, 29.443237, 27.691347],
    [12.660389, 30.565388, 29.655706, 27.16332],
    [12.083317, 31.082693, 29.869383, 26.93505]
])

# 颜色选项 - 10
color_10 = ['#930f02', '#028693', '#930f02']
plt.figure(figsize=(12, 8))
for i, component in enumerate(gas_component_labels):
    plt.subplot(3, 3, i + 1)
    predicted_values = [predicted_results[concentration][i] for concentration in DFA_CS]
    actual_values = gas_components[:, i]
    plt.plot(DFA_CS, predicted_values, color='#475258', label="Predicted", linestyle="--", linewidth=2)

    plt.scatter(DFA_CS, actual_values, color='#fa5c4f', linestyle="--", alpha=0.5)
    plt.plot(DFA_CS, actual_values, color='#fa5c4f', alpha=0.5)
    plt.xlabel("DFA/CS Ratio")
    plt.ylabel(f"{component} Output")
    plt.title(f"Prediction of {component} Output")

    if i == 0:
        plt.legend(labels=["Predicted", "Actual"])

    # Adding grid lines
    plt.grid(True, linestyle='-', alpha=0.5)
    plt.title(f"{component} Yield", fontsize=12, fontweight='bold')
    plt.xlabel("DFA/CS Concentration", fontsize=12, fontweight='bold')
    plt.ylabel(f"{component} Yield", fontsize=12, fontweight='bold')
    plt.xticks(fontsize=10, fontweight='bold')
    plt.yticks(fontsize=10, fontweight='bold')

plt.tight_layout()
plt.savefig(r'F:\建模比赛\图片\第五题\多元线性\神经网络\predicted_results_10-10.png', dpi=600, bbox_inches='tight')
plt.show()
