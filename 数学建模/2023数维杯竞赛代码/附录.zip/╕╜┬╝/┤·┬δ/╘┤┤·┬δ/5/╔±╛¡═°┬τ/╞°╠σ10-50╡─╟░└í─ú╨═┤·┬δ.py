import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from keras.models import Sequential
from keras.layers import Dense
from sklearn.preprocessing import StandardScaler
import time

# Data definition
DFA_CS = np.array([0, 20, 40, 50, 80, 100])  # DFA/CS Ratio
# Gas components: H2, CO, CO2, CH4, C2H6, C3H8, C3H6, C2H4, C4H10
gas_components = np.array([
    [6.48, 25.93, 60.4, 23.41, 2.09, 0.55, 0.35, 0.71, 0.32],
    [12.94, 21.61, 57.84, 28.79, 2.73, 0.61, 0.37, 0.74, 0.48],
    [22.65, 20.53, 52.31, 33.11, 3.08, 0.62, 0.41, 0.81, 0.56],
    [30.35, 20.95, 51.92, 32.45, 2.99, 0.71, 0.39, 0.79, 0.37],
    [37.93, 22.00, 51.53, 30.83, 2.96, 0.88, 0.37, 0.77, 0.28],
    [43.62, 23.32, 50.91, 30.21, 2.94, 0.87, 0.38, 0.75, 0.25]
])

hidden_layers = [10, 50]
results_df = pd.DataFrame(columns=["Hidden Layers", "Runtime (seconds)"])
all_predicted_values = {}

for i in hidden_layers:
    # Record start time
    start_time = time.time()

    # Convert DFA/CS concentration to matrix form for model input
    X = DFA_CS.reshape(-1, 1)
    y = gas_components  # Gas components as output

    # Data normalization
    scaler_X = StandardScaler()
    scaler_y = StandardScaler()
    X_scaled = scaler_X.fit_transform(X)
    y_scaled = scaler_y.fit_transform(y)

    # Create neural network model
    model = Sequential()
    model.add(Dense(i, input_dim=1, activation='relu'))  # Input and first hidden layer
    model.add(Dense(i, activation='relu'))  # Second hidden layer
    model.add(Dense(9))  # Output layer, 9 neurons for 9 gas components

    # Compile model
    model.compile(loss='mean_squared_error', optimizer='adam')

    # Fit model
    model.fit(X_scaled, y_scaled, epochs=2000, batch_size=10, verbose=0)

    # Store predictions for each concentration point
    predicted_values = {}
    for concentration in DFA_CS:
        X_new = np.array([[concentration]])
        X_new_scaled = scaler_X.transform(X_new)
        y_new_pred_scaled = model.predict(X_new_scaled)
        y_new_pred = scaler_y.inverse_transform(y_new_pred_scaled)
        predicted_values[concentration] = y_new_pred[0]

    all_predicted_values[i] = predicted_values

    # Plotting
    plt.figure(figsize=(12, 8))
    for j, component in enumerate(["H2", "CO", "CO2", "CH4", "C2H6", "C3H8", "C3H6", "C2H4", "C4H10"]):
        plt.subplot(3, 3, j + 1)

        plt.scatter(DFA_CS, [predicted_values[concentration][j] for concentration in DFA_CS], color='#d6338a', label="Predicted")
        plt.plot(DFA_CS, y[:, j], color='#b06524', linestyle="--", label="Actual")


        plt.xlabel("DFA/CS Ratio")
        plt.ylabel(f"{component} Output")
        plt.title(f"Prediction of {component} Output")
        plt.grid(True)
        plt.legend()

    plt.tight_layout()
    plt.show()

    # Record end time
    end_time = time.time()
    runtime = end_time - start_time
    results_df = results_df.append({"Hidden Layers": f"{i}-{i}", "Runtime (seconds)": runtime}, ignore_index=True)

# Display results
print(results_df)

# Output predicted results for each hidden layer configuration
for i in hidden_layers:
    print(f"\nPredicted Results for Hidden Layers {i}-{i}:")
    for concentration in DFA_CS:
        print(f"  Concentration {concentration}%:")
        for j, component in enumerate(["H2", "CO", "CO2", "CH4", "C2H6", "C3H8", "C3H6", "C2H4", "C4H10"]):
            print(f"    {component}: {all_predicted_values[i][concentration][j]}")
