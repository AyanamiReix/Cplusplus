import numpy as np
import matplotlib.pyplot as plt

# DFA/CS比例和气体组分真实值
DFA_CS = np.array([0, 0.2, 0.4, 0.5, 0.8, 1])  # DFA/CS Ratio
gas_components = np.array([
    [6.48, 25.93, 60.4, 23.41, 2.09, 0.55, 0.35, 0.71, 0.32],
    [12.94, 21.61, 57.84, 28.79, 2.73, 0.61, 0.37, 0.74, 0.48],
    [22.65, 20.53, 52.31, 33.11, 3.08, 0.62, 0.41, 0.81, 0.56],
    [30.35, 20.95, 51.92, 32.45, 2.99, 0.71, 0.39, 0.79, 0.37],
    [37.93, 22.00, 51.53, 30.83, 2.96, 0.88, 0.37, 0.77, 0.28],
    [43.62, 23.32, 50.91, 30.21, 2.94, 0.87, 0.38, 0.75, 0.25]
])

# 您提供的预测结果（隐藏层为10的配置）
predicted_results = {
    0: [6.652854919433594, 25.92812156677246, 60.402103424072266, 23.392728805541992, 2.0922751426696777, 0.5480701923370361, 0.35022568702697754, 0.7085731029510498, 0.32015717029571533],
    0.2: [12.621910095214844, 21.62555694580078, 57.84501647949219, 28.834178924560547, 2.7270476818084717, 0.6131409406661987, 0.36982783675193787, 0.7417119741439819, 0.478880375623703],
    0.4: [22.794395446777344, 20.51352882385254, 52.296775817871094, 33.122928619384766, 3.0831966400146484, 0.6182456612586975, 0.4098310172557831, 0.8095566630363464, 0.5584145784378052],
    0.5: [30.076190948486328, 20.924880981445312, 51.97231674194336, 32.378170013427734, 2.9867348670959473, 0.7137424349784851, 0.3892781436443329, 0.7907568216323853, 0.37471407651901245],
    0.8: [39.72593307495117, 22.114013671875, 51.49538803100586, 30.807098388671875, 2.9639008045196533, 0.8621217012405396, 0.3741512596607208, 0.7624199390411377, 0.27744120359420776],
    1.0: [42.268272399902344, 23.24849510192871, 50.90665054321289, 30.257741928100586, 2.9374940395355225, 0.882595956325531, 0.37715309858322144, 0.7556465268135071, 0.2505347728729248]
}
# 气体组分标签
gas_component_labels = ["H2", "CO", "CO2", "CH4", "C2H6", "C3H8", "C3H6", "C2H4", "C4H10"]

# 绘制图表
plt.figure(figsize=(12, 8))
for i, component in enumerate(gas_component_labels):
    plt.subplot(3, 3, i + 1)
    predicted_values = [predicted_results[concentration][i] for concentration in DFA_CS]
    actual_values = gas_components[:, i]
    plt.plot(DFA_CS, predicted_values, color='#475258', label="Predicted", linestyle="--", linewidth=2)

    plt.scatter(DFA_CS, actual_values, color='#fa5c4f', linestyle="--", alpha=0.5)
    plt.plot(DFA_CS, actual_values, color='#fa5c4f', alpha=0.5)
    plt.xlabel("DFA/CS Ratio")
    plt.ylabel(f"{component} Output")
    plt.title(f"Prediction of {component} Output")


    plt.legend(labels=["Predicted(10-10)", "Actual"])

    # Adding grid lines
    plt.grid(True, linestyle='-', alpha=0.8)
    plt.title(f"{component} Yield", fontsize=10, fontweight='bold')
    plt.xlabel("DFA/CS Concentration", fontsize=10, fontweight='bold')
    plt.ylabel(f"{component} Yield", fontsize=10, fontweight='bold')
    plt.xticks(fontsize=8, fontweight='bold')
    plt.yticks(fontsize=8, fontweight='bold')

plt.tight_layout()
plt.savefig(r'F:\建模比赛\图片\第五题\神经网络\predicted_results_10-10.png', dpi=600, bbox_inches='tight')
plt.show()
