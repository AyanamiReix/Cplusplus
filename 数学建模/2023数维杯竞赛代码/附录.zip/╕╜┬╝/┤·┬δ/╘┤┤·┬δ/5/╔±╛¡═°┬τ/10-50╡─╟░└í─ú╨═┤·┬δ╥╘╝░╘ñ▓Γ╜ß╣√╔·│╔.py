# Python Learning Process
# Name: Ayanami_LJ
# Time: 2023/3/16

import matplotlib.pyplot as plt
import numpy as np
from keras.models import Sequential
from keras.layers import Dense
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import time
import pandas as pd


DFA_CS = np.array([0, 10, 20, 30, 40, 50, 60, 80, 100])
tar_yield = np.array([19.46, 17.25, 15.43, 14.14, 13.89, 13.21, 12.84, 12.57, 12.13])
water_yield = np.array([26.84, 27.64, 28.11, 28.23, 28.62, 29.01, 30.07, 30.68, 31.02])
char_yield = np.array([29.21, 29.11, 29.3, 29.34, 29.14, 29.33, 29.47, 29.64, 29.87])
syngas_yield = np.array([24.49, 26, 27.16, 28.29, 28.35, 28.45, 27.62, 27.11, 26.98])

hidden_layers = [10, 50]

# 创建一个空的DataFrame来存储结果
results_df = pd.DataFrame(columns=["Hidden Layers", "Runtime (seconds)"])

for i in hidden_layers:
    # 记录开始时间
    start_time = time.time()

    # 将DFA/CS浓度转换为矩阵形式以用作模型的输入
    X = DFA_CS.reshape(-1, 1)

    # 四种产物的产量作为输出
    y = np.vstack((tar_yield, water_yield, char_yield, syngas_yield)).T

    # 数据标准化
    scaler_X = StandardScaler()
    scaler_y = StandardScaler()
    X_scaled = scaler_X.fit_transform(X)
    y_scaled = scaler_y.fit_transform(y)

    # 创建神经网络模型
    model = Sequential()
    model.add(Dense(i, input_dim=1, activation='relu'))  # 输入层和第一个隐藏层
    model.add(Dense(i, activation='relu'))  # 第二个隐藏层
    model.add(Dense(4))  # 输出层，4个神经元对应4种产物

    # 编译模型
    model.compile(loss='mean_squared_error', optimizer='adam')

    # 拟合模型
    model.fit(X_scaled, y_scaled, epochs=2000, batch_size=10, verbose=0)

    # 存储每个浓度点的预测结果
    predicted_values = {}

    # 循环预测每个浓度点
    # 循环预测每个浓度点
    for concentration in DFA_CS:
        # 创建新的浓度点
        X_new = np.array([[concentration]])
        X_new_scaled = scaler_X.transform(X_new)  # 标准化
        y_new_pred_scaled = model.predict(X_new_scaled)  # 预测
        y_new_pred = scaler_y.inverse_transform(y_new_pred_scaled)  # 反标准化获取实际预测值

        # 存储预测结果
        predicted_values[concentration] = y_new_pred[0]

    # 打印预测结果
    for concentration, values in predicted_values.items():
        print(f"Predicted yields at DFA/CS concentration {concentration}: {values}")

    # 绘制散点图
    if i in [10, 50]:
        plt.figure(figsize=(12, 8), dpi=300)

        # 指定颜色
        scatter_color = (2 / 255, 134 / 255, 147 / 255)  # RGB格式
        line_color = (147 / 255, 15 / 255, 2 / 255)  # RGB格式

        # 绘制每个浓度点的预测值
        for j, component in enumerate(["Tar", "Water", "Char", "Syngas"]):
            plt.subplot(2, 2, j + 1)
            plt.scatter(DFA_CS, [predicted_values[concentration][j] for concentration in DFA_CS], label="Predicted",
                        color=scatter_color)
            plt.plot(DFA_CS, y[:, j], label="True", linestyle="--", color=line_color)  # 设置虚线颜色为指定颜色
            plt.xlabel("DFA/CS Concentration")
            plt.ylabel(f"{component} Yield")
            plt.legend()

        # 添加网格线
        plt.grid(True)
        # 记录结束时间
        end_time = time.time()
        plt.tight_layout()
        #plt.show()


    # 计算运行时间
    run_time = end_time - start_time

    # 输出运行时间
    print(f"Runtime for {i}-{i} Hidden Layers: {run_time:.2f} seconds")

    # 将结果添加到DataFrame
    results_df = pd.concat([results_df, pd.DataFrame({"Hidden Layers": [f"{i}-{i}"], "Runtime (seconds)": [run_time]})],
                           ignore_index=True)

# 输出结果表格
print(results_df)
