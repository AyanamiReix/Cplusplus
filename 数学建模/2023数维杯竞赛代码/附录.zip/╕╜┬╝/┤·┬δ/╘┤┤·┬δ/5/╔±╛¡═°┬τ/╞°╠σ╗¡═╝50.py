import numpy as np
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

# DFA/CS比例和气体组分真实值
DFA_CS = np.array([0, 0.2, 0.4, 0.5, 0.8, 1])  # DFA/CS Ratio
gas_components = np.array([
    [6.48, 25.93, 60.4, 23.41, 2.09, 0.55, 0.35, 0.71, 0.32],
    [12.94, 21.61, 57.84, 28.79, 2.73, 0.61, 0.37, 0.74, 0.48],
    [22.65, 20.53, 52.31, 33.11, 3.08, 0.62, 0.41, 0.81, 0.56],
    [30.35, 20.95, 51.92, 32.45, 2.99, 0.71, 0.39, 0.79, 0.37],
    [37.93, 22.00, 51.53, 30.83, 2.96, 0.88, 0.37, 0.77, 0.28],
    [43.62, 23.32, 50.91, 30.21, 2.94, 0.87, 0.38, 0.75, 0.25]
])

# 新的预测结果
predicted_results = {
    0: [6.480001449584961, 25.93000030517578, 60.400001525878906, 23.410001754760742, 2.0899999141693115, 0.550000011920929, 0.3499999940395355, 0.7099999785423279, 0.320000022649765],
    0.2: [12.940000534057617, 21.610000610351562, 57.839996337890625, 28.78999900817871, 2.7300000190734863, 0.6100000143051147, 0.3700000047683716, 0.7400000095367432, 0.48000001907348633],
    0.4: [22.649999618530273, 20.529998779296875, 52.31000518798828, 33.11000061035156, 3.0799999237060547, 0.6200000047683716, 0.4099999964237213, 0.809999942779541, 0.559999942779541],
    0.5: [30.35000228881836, 20.950000762939453, 51.91999435424805, 32.45000076293945, 2.989999771118164, 0.7099999785423279, 0.38999998569488525, 0.7900000214576721, 0.37000012397766113],
    0.8: [37.93000030517578, 22.0, 51.53000259399414, 30.829999923706055, 2.9600000381469727, 0.8799999952316284, 0.3700000047683716, 0.7699999809265137, 0.2799999713897705],
    1: [43.619998931884766, 23.31999969482422, 50.90999984741211, 30.209999084472656, 2.940000057220459, 0.8700000047683716, 0.3799999952316284, 0.75, 0.2500000298023224]
}
# 气体组分标签
gas_component_labels = ["H2", "CO", "CO2", "CH4", "C2H6", "C3H8", "C3H6", "C2H4", "C4H10"]

# 绘制图表
plt.figure(figsize=(12, 8))
for i, component in enumerate(gas_component_labels):
    plt.subplot(3, 3, i + 1)
    predicted_values = [predicted_results[concentration][i] for concentration in DFA_CS]
    actual_values = gas_components[:, i]
    plt.plot(DFA_CS, predicted_values, color='#475258', label="Predicted", linestyle="--", linewidth=2)

    plt.scatter(DFA_CS, actual_values, color='#fa5c4f', linestyle="--", alpha=0.5)
    plt.plot(DFA_CS, actual_values, color='#fa5c4f', alpha=0.5)
    plt.xlabel("DFA/CS Ratio")
    plt.ylabel(f"{component} Output")
    plt.title(f"Prediction of {component} Output")


    legend = plt.legend(labels=["Predicted(50-50)", "Actual"])

    # Adding grid lines
    plt.grid(True, linestyle='-', alpha=0.8)
    plt.title(f"{component} Yield", fontsize=10, fontweight='bold')
    plt.xlabel("DFA/CS Concentration", fontsize=10, fontweight='bold')
    plt.ylabel(f"{component} Yield", fontsize=10, fontweight='bold')
    plt.xticks(fontsize=8, fontweight='bold')
    plt.yticks(fontsize=8, fontweight='bold')

plt.tight_layout()
plt.savefig(r'F:\建模比赛\图片\第五题\神经网络\predicted_results_50_50.png', dpi=600, bbox_inches='tight')
plt.show()
