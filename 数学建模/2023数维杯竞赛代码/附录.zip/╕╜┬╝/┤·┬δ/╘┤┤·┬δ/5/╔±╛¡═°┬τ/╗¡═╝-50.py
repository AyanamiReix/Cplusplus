import matplotlib.pyplot as plt
import numpy as np
import os
# 共享的x轴数据
concentrations = np.array([0, 0.1, 0.20, 0.30, 0.40, 0.50, 0.60, 0.80, 1])

# 预测结果数据 - 50
predicted_results_50 = np.array([
    [19.461878, 26.839437, 29.209866, 24.490664],
    [17.245523, 27.641294, 29.110361, 25.99825],
    [15.432824, 28.109411, 29.299791, 27.161371],
    [14.139593, 28.22994, 29.339989, 28.28988],
    [13.890083, 28.620043, 29.140007, 28.350035],
    [13.210197, 29.010036, 29.330006, 28.449942],
    [12.838714, 30.070024, 29.469936, 27.619955],
    [12.575682, 30.67885, 29.639984, 27.11012],
    [12.12654, 31.0208, 29.870039, 26.97988]
])

# 真实值数据 - 50
tar_yield_50 = np.array([19.46, 17.25, 15.43, 14.14, 13.89, 13.21, 12.84, 12.57, 12.13])
water_yield_50 = np.array([26.84, 27.64, 28.11, 28.23, 28.62, 29.01, 30.07, 30.68, 31.02])
char_yield_50 = np.array([29.21, 29.11, 29.3, 29.34, 29.14, 29.33, 29.47, 29.64, 29.87])
syngas_yield_50 = np.array([24.49, 26, 27.16, 28.29, 28.35, 28.45, 27.62, 27.11, 26.98])

# 颜色选项 - 50
color_50 = ['#930f02', '#028693', '#93023e']

# 绘制图表 - 50
plt.figure(figsize=(12, 8))

# 绘制每个浓度点的预测曲线 - 50
for i, component in enumerate(["Tar", "Water", "Char", "Syngas"]):
    plt.subplot(2, 2, i + 1)
    plt.plot(concentrations, predicted_results_50[:, i], label="Predicted (50-50)", color=color_50[0], linestyle='--',
             alpha=1, linewidth=2)
    plt.plot(concentrations, globals()[f"{component.lower()}_yield_50"], label="True", color=color_50[1], alpha=0.45,
             linewidth=2)

    # 标出True的点
    plt.scatter(concentrations, globals()[f"{component.lower()}_yield_50"], color=color_50[1], marker='o', alpha=1)

    plt.xlabel("DFA/CS Concentration")
    plt.ylabel(f"{component} Yield")
    plt.legend()

    # 添加网格线（实线）
    plt.grid(True, linestyle='-', alpha=0.5)

    # 加粗字体
    plt.title(f"{component} Yield", fontsize=12, fontweight='bold')
    plt.xlabel("DFA/CS Concentration", fontsize=12, fontweight='bold')
    plt.ylabel(f"{component} Yield", fontsize=12, fontweight='bold')
    plt.xticks(fontsize=10, fontweight='bold')
    plt.yticks(fontsize=10, fontweight='bold')

# 调整图表参数
plt.tight_layout()

# 保存图表为高分辨率图像 - 50
plt.savefig("predicted_yields_50.png", dpi=600)
output_dir = r"F:\建模比赛\图片\第五题\多元线性\神经网络"
output_file = os.path.join(output_dir, "predicted_yields_50.png")
plt.savefig(output_file, dpi=600)

# 显示图表 - 50
plt.show()
