% Data provided by the user
ratios = [10, 20, 30, 40, 50, 60, 80, 100];  % Ratios as integers for simplicity
Tar_Yield = [34.42, 38.31, 42.69, 43.78, 44.53, 44.41, 43.24, 45.28];
Water_Yield = [27.42, 21.37, 17.84, 16.9, 16.25, 18.25, 19.93, 16.14];
Char_Yield = [21.43, 24.91, 24.17, 24.7, 24.54, 24.59, 23.57, 24.61];
Syngas_Yield = [16.73, 15.41, 15.3, 14.62, 14.68, 12.75, 13.26, 13.97];

% Normalizing the yields so that each column adds up to 100%
total_yield = Tar_Yield + Water_Yield + Char_Yield + Syngas_Yield;
norm_Tar_Yield = Tar_Yield ./ total_yield * 100;
norm_Water_Yield = Water_Yield ./ total_yield * 100;
norm_Char_Yield = Char_Yield ./ total_yield * 100;
norm_Syngas_Yield = Syngas_Yield ./ total_yield * 100;

% Preparing the data for stacked bar plot
stacked_data = [norm_Tar_Yield', norm_Water_Yield', norm_Char_Yield', norm_Syngas_Yield'];

% Plotting the stacked bar chart
figure;
bar(ratios./100, stacked_data, 0.5, 'stacked');  % Dividing by 100 to get the actual ratio
colormap([0 0.5 0; 0 0.75 0; 0 1 0]);  % Shades of green
xlabel('DFA/CE Ratio');
ylabel('Normalized Yield (%)');
title('Normalized Yield of Decomposition Products from DFA/CE Pyrolysis');
legend('Tar Yield', 'Water Yield', 'Char Yield', 'Syngas Yield', 'Location', 'NorthEastOutside');

% Set the x-axis ticks to only include the ratios where there is data
set(gca, 'XTick', ratios./100);

% Save the figure as a file
saveas(gcf, 'pyrolysis_yield_plot.png');
grid on;
