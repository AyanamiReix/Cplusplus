% Updated data for Yield of Gaseous Components from DFA/CE Pyrolysis
ratios = [0.20, 0.40, 0.50, 0.80, 1];  % Updated ratios
H2_Yield = [0.35, 0.607369759, 0.738379814, 0.820448878, 0.837916064];
CO_Yield = [0.180263158, 0.134688691, 0.107569721, 0.081047382, 0.076700434];
CO2_Yield = [0.246052632, 0.124523507, 0.078353254, 0.039900249, 0.02894356];
CH4_Yield = [0.042105263, 0.024142313, 0.017264276, 0.016209476, 0.010130246];
C2H6_Yield = [0.181578947, 0.109275731, 0.058432935, 0.042394015, 0.046309696];





% Preparing the data for stacked bar plot
stacked_data = [H2_Yield', CO_Yield', CO2_Yield', CH4_Yield', C2H6_Yield'];

% Calculate the total width for each set of bars and adjust the bar width
total_width = 1.2;  % Increased width
bar_width = total_width / length(ratios);

% Calculate the x-positions for the bars
x_positions = (1:length(ratios)) - total_width/2 + bar_width/2;

% Plotting the stacked bar chart with wider bars
figure;
bar(x_positions, stacked_data, bar_width, 'stacked');
colormap([0 0 1; 0 0.5 0.5; 0.5 0 0; 1 0 0; 0.5 0.5 0]);
xlabel('DFA/CE Ratio');
ylabel('Yield (mL/g,daf)');
title('Yield of Gaseous Components from DFA/CE Pyrolysis');
legend('H2', 'CO', 'CO2', 'CH4', 'C2H6', 'Location', 'NorthEastOutside');

% Set the y-axis limit to be between 0 and 1
ylim([0, 1]);

% Set the x-axis ticks to only include the updated ratios
set(gca, 'XTick', x_positions);

% Customize x-axis labels to match the original ratios
xticklabels(cellstr(num2str(ratios')));

% Save the figure as a file
saveas(gcf, 'gaseous_yield_plot.png');
grid on;
