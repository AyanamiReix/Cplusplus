% Updated data for Yield of Gaseous Components from DFA/CS Pyrolysis
ratios = [0.1, 0.2, 0.4, 0.5, 0.8, 1];  % Updated ratios
H2_Yield = [0.053892216, 0.102608834, 0.168928998, 0.215370423, 0.257065402, 0.284632953];
CO_Yield = [0.215652029, 0.171358338, 0.153117542, 0.14866591, 0.149101999, 0.152169657];
CO2_Yield = [0.502328676, 0.458647213, 0.390140215, 0.368435992, 0.349237547, 0.332202284];
CH4_Yield = [0.194693945, 0.22829276, 0.246942124, 0.230272495, 0.20894612, 0.197128874];
C2H6_Yield = [0.017381903, 0.021647768, 0.02297136, 0.021217712, 0.020060996, 0.019184339];
C3H8_Yield = [0.004574185, 0.004837047, 0.004624105, 0.00503832, 0.00596408, 0.005676998];
C3H6_Yield = [0.002910845, 0.002933947, 0.003057876, 0.002767528, 0.002507625, 0.002479608];
C2H4_Yield = [0.005904857, 0.005867893, 0.006041169, 0.005606018, 0.00521857, 0.004893964];
C4H10_Yield = [0.002661344, 0.003806201, 0.004176611, 0.002625603, 0.001897662, 0.001631321];

% Preparing the data for stacked bar plot
stacked_data = [H2_Yield', CO_Yield', CO2_Yield', CH4_Yield', C2H6_Yield', C3H8_Yield', C3H6_Yield', C2H4_Yield', C4H10_Yield'];

% Calculate the total width for each set of bars and adjust the bar width
total_width = 1.5;  % Increased width
bar_width = total_width / length(ratios);

% Calculate the x-positions for the bars
x_positions = (1:length(ratios)) - total_width/2 + bar_width/2;

% Plotting the stacked bar chart with wider bars
figure;
bar(x_positions, stacked_data, bar_width, 'stacked');
colormap('jet');  % You can change the colormap if desired
xlabel('DFA/CS Ratio');
ylabel('Yield (mL/g,daf)');
title('Yield of Gaseous Components from DFA/CS Pyrolysis');
legend('H2', 'CO', 'CO2', 'CH4', 'C2H6', 'C3H8', 'C3H6', 'C2H4', 'C4H10', 'Location', 'NorthEastOutside');

% Set the y-axis limit to be between 0 and 1
ylim([0, 1]);

% Set the x-axis ticks to only include the updated ratios
set(gca, 'XTick', x_positions);

% Customize x-axis labels to match the original ratios
xticklabels(cellstr(num2str(ratios')));

% Save the figure as a file
saveas(gcf, 'gaseous_yield_plot_updated.png');
grid on;
