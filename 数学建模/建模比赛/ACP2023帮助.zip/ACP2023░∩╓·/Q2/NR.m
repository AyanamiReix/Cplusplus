clc
clear
data=xlsread('新能源车企申请专利数量');
table=data(1:end,2)';
refer_date=size(data,2); %参考期
step=10; %预测未来15期

%% 下面是回归
i=1;
    %只获取有历史数据的阶段
    lr_data=table;
    %通过LR算法进行预测
    [k]=polyfit(1:size(lr_data,2),lr_data,3);
    x=[refer_date+1:refer_date+step];
    for kk=1:length(x)
%         forData(kk)=k(1)*x(kk).^4+k(2)*x(kk).^3+k(3)*x(kk).^2+k(4)*x(kk)+k(5);
forData(kk)=k(3)*x(kk).^3+k(2)*x(kk).^2+k(3)*x(kk)+k(4);
    end
figure
    plot(1:length(lr_data),lr_data)
    hold on
    plot((length(lr_data)):length(lr_data)+step,[lr_data(end) forData])
    hold on
    hXLabel = xlabel('Year');
    hYLabel = ylabel('Number of patents applied forby new energy vehicle enterprises');
    set(gcf,'Color',[1 1 1])