clc
clear
data=xlsread('新能源车企申请专利数量');
data=data(1:end-1,2);
step=10;
[forData]=ARIMA(data,step);
