clc;
clear;
point = xlsread('Consolidated table.xlsx');
color = [223/255, 53/255, 48/255;
         130/255, 176/255, 210/255;
         190/255, 184/255, 220/255;
         231/255, 218/255, 210/255;
         153/255, 153/255, 153/255];
     
figure(1);
scatter3(point(:,1), point(:,2), point(:,3), [], color(1,:), 'filled')
hold on
xlabel('Number of Charging Piles', 'Color', 'k', 'FontSize', 14, 'FontName', 'Times New Roman')
ylabel('Population (10,000)', 'Color', 'k', 'FontSize', 14, 'FontName', 'Times New Roman')
zlabel('Comprehensive Environmental Pollution Index', 'Color', 'k', 'FontSize', 14, 'FontName', 'Times New Roman')

x = [0:100:max(point(:,1))];
y = [0:100:max(point(:,2))];
[X, Y] = meshgrid(x, y);
p1 = -8886.0736394066;
p2 = 1.97957878403193E-6;
p3 = -2.12440068861636E-11;
p4 = 4272.58687746262;
p5 = -769.476413873198;
p6 = 61.5188299361025;
p7 = -1.84217149523183;
Z = p1 + p2*X + p3*X.^2 + p4*log(Y) + p5*(log(Y)).^2 + p6*(log(Y)).^3 + p7*(log(Y)).^4;
Z(1,1) = Z(1,2);

% Plot the surface and use the "parula" colormap
Fig = mesh(X, Y, Z);
colormap(parula) % Use the "parula" colormap
colorbar

% Adjust the legend size to 0.5x
hLegend = legend('Actual Value', 'Fitting Surface', 'FontSize', 8, 'FontName', 'Times New Roman');
set(hLegend, 'Units', 'normalized', 'Position', [0.8, 0.8, 0.1, 0.1]) % Adjust legend position and size

set(gcf, 'Color', [1 1 1])
set(gca, 'FontSize', 8.5) % Set the font size for tick labels
