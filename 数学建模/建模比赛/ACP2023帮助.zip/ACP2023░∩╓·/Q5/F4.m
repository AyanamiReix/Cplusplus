clc
clear
data = xlsread('Consolidated table.xlsx');

D1 = data;

% 将点的大小放大1.5倍
pointSize = 8 * 2;

% 设置要使用的颜色
pointColor = [223/255, 48/255, 175/255];  % 十六进制颜色 "#a91a3a" 的 RGB 值

scatter3(D1(:, 1), D1(:, 2), D1(:, 3), pointSize, pointColor, 'filled')
hold on

hXLabel = xlabel('Charging station quantity');
hYLabel = ylabel('Population/10000');
hZLabel = zlabel('Comprehensive environmental pollution index');
set(gcf, 'Color', [1 1 1])
set([hXLabel, hYLabel, hZLabel], 'FontName', 'Times New Roman')
set(gca, 'FontSize', 10)
set([hXLabel, hYLabel, hZLabel], 'FontSize', 9)
