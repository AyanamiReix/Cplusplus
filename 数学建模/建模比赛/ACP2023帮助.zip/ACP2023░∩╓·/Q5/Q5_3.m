clc;
clear;
point = xlsread('Consolidated table.xlsx');
color = [250/255, 127/255, 111/255;
         130/255, 176/255, 210/255;
         190/255, 184/255, 220/255;
         231/255, 218/255, 210/255;
         153/255, 153/255, 153/255];
Y = 100;
X = [0:100:max(point(:,1))];
p1 = -8886.0736394066;
p2 = 1.97957878403193E-6;
p3 = -2.12440068861636E-11;
p4 = 4272.58687746262;
p5 = -769.476413873198;
p6 = 61.5188299361025;
p7 = -1.84217149523183;
% Z = (p1 + p2*X + p3*X.^2 + p4*Y + p5*Y.^2) / (1 + p6*X + p7*Y);
Z = p1 + p2*X + p3*X.^2 + p4*log(Y) + p5*(log(Y)).^2 + p6*(log(Y)).^3 + p7*(log(Y)).^4;
plot(X, Z, 'color', color(1,:), 'LineWidth', 2)
xlabel({'Number of Charging Piles'}, 'Color', 'k', 'FontSize', 11, 'FontName', 'Times New Roman')
ylabel({'Comprehensive Environmental Pollution Index'}, 'Color', 'k', 'FontSize', 11, 'FontName', 'Times New Roman')
set(gcf, 'Color', [1 1 1])
grid on % Add grid lines
