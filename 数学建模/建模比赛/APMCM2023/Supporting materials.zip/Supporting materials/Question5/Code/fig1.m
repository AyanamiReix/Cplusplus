
clc
clear
data = xlsread('Consolidated table.xlsx');

D1 = data;

% Enlarge the size of points by 1.5 times
pointSize = 8 * 2;

% Set the color to be used
pointColor = [223/255, 48/255, 175/255]; % RGB value of hexadecimal color "#a91a3a"

scatter3(D1(:, 1), D1(:, 2), D1(:, 3), pointSize, pointColor, 'filled')
hold on

hXLabel = xlabel('Charging Station Quantity');
hYLabel = ylabel('Population/10,000');
hZLabel = zlabel('Comprehensive Environmental Pollution Index');
set(gcf, 'Color', [1 1 1])
set([hXLabel, hYLabel, hZLabel], 'FontName', 'Times New Roman')
set(gca, 'FontSize', 10)
set([hXLabel, hYLabel, hZLabel], 'FontSize', 9)