clc
clear
A = xlsread('AHP Judgment Matrix.xlsx');

[n, n] = size(A);

[V, D] = eig(A); % Calculate all eigenvalues of matrix A, form diagonal matrix D, and calculate eigenvectors of A forming column vectors in V.
Max_eig = max(max(D));
[r, c] = find(D == Max_eig, 1);
disp('Results of Eigenvalue Method for Weight Calculation:');
w = V(:,c) ./ sum(V(:,c));
disp(w)

% % % % % % % % % % % % % The following calculates the Consistency Ratio CR % % % % % % % % % % % %
CI = (Max_eig - n) / (n - 1);
RI = [0 0.0001 0.52 0.89 1.12 1.26 1.36 1.41 1.46 1.49 1.52 1.54 1.56 1.58 1.59];  % Note that RI supports up to n = 15
% When n = 2, the matrix is always consistent, so CI = 0. To avoid a denominator of 0, we set the second element here to a very small positive number.
CR = CI / RI(n);
disp('Consistency Index CI ='); disp(CI);
disp('Consistency Ratio CR ='); disp(CR);
if CR < 0.10
    disp('Since CR < 0.10, the consistency of judgment matrix A is acceptable!');
else
    disp('Attention: CR >= 0.10, so judgment matrix A needs to be modified!');
end
