function [forData] = ARIMA(data, step, count)
ytick_labels1 = {'Annual sales volume (Forecast)', 'Related patent applications' ...
    ' quantity (Forecast)', 'Charging station quantity (Forecast)', 'Annual per capita GDP (Forecast)'};
ddata = data;
d = 2;
while kpsstest(ddata) == 1
    ddata = diff(data);
    d = d + 1;
    if d > 3
        break
    end
end

% Test data stationarity
adftest(data);
kpsstest(data);

% First-order differencing and stationarity test
ddata = diff(data);
d1_adf = adftest(ddata);
d1_kpss = kpsstest(ddata);

%% Calculate p and q values
pmax = 3;
qmax = 3;
[p, q] = findPQ(data, pmax, qmax, d);

%% Build the model
Mdl = arima(p, d, q);  % The second variable is set to 1 for first-order differencing
EstMdl = estimate(Mdl, data);

%% Model prediction
[forData, YMSE] = forecast(EstMdl, step, 'Y0', data);

% Plot the figure
figure
grid on;
plot(1:length(data), data)
hold on
plot((length(data) + 1):(length(data) + step), forData)
hold on

% Modify y-axis label
hXLabel = xlabel('Year');
hYLabel = ylabel(ytick_labels1(count));

% Modify font size
set(hXLabel, 'FontSize', 12);
set(hYLabel, 'FontSize', 12);

% Modify x-axis range
xticks([1:length(data), (length(data) + 1):(length(data) + step)]);
xticklabels({'2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025', '2026', '2027', '2028', '2029', '2030', '2031', '2032'});

% Set x-axis label positions
xtick_positions = [1, 4, 7, 10, 13, 16, 19, 22, 25];

% Set custom x-axis labels
xtick_labels = {'2011', '2014', '2017', '2020', '2023', '2026', '2029', '2032'};

% Modify x-axis range
xticks(xtick_positions);
xticklabels(xtick_labels);
set(gcf, 'Color', [1 1 1]);

% Add legend
legend('Annual per capita GDP', 'Forecasted per capita GDP', 'Location', 'SouthEast');
grid on;
end
