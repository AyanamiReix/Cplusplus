clc
clear
ytick_labels1 = {
    'Annual sales volume', 
    'Related patent applications quantity', 
    'Charging station quantity', 
    'Annual per capita GDP'
};
% Load the data from the '4Tables_total.xlsx' Excel file
data = xlsread('4Tables_total.xlsx');

% Extract the relevant data columns (2nd, 3rd, 4th, and 5th)
columns_to_forecast = data(:, 2:5);

refer_date = size(data, 1); % Number of rows, assuming each row corresponds to a year

% Initialize a cell array to store forecasted data for each column
forecasted_data = cell(1, size(columns_to_forecast, 2));

% Define the range of values for i (from 1 to 3)
for i = 1:3
    % Loop through each column and perform forecasting
    for col = 1:size(columns_to_forecast, 2)
        % Get the data for the current column
        column_data = columns_to_forecast(:, col)';
        
        % Polynomial regression for forecasting
        coefficients = polyfit(1:(refer_date-i), column_data(1:end-i), 3); % Use data up to the (length-i)-th point
        x = refer_date - i + 1;
        forData = polyval(coefficients, x);
        
        % Store the forecasted data in the cell array
        forecasted_data{col} = [forecasted_data{col}, forData];
    end
end

% Display the forecasted data
for col = 1:size(columns_to_forecast, 2)
    fprintf('Forecasted data for %s:\n', ytick_labels1{col});
    disp(forecasted_data{col});
end
