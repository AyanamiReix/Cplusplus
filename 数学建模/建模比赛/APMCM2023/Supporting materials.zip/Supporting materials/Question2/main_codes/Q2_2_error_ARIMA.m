
clc
clear
data = xlsread('4Tables_total.xlsx');
% Read data from an Excel file

% Set the forecasting period
step = 1;
num_columns_to_forecast=4;
% Initialize an array to store forecast results for each column
forecast_results = zeros(size(data, 1), num_columns_to_forecast);
i=3;
% Loop through columns 2 to 5
for column = 5:5
    % Extract data column
    column_data = data(:, column);
    
    % Split the data into training and testing sets
    training_data = column_data(1:end-i);
    testing_data = column_data(end-i+1);
    
    % Call the ARIMA1 function for forecasting
    [forData] = ARIMA_for_error(training_data, step);
    

end

% Display the forecast results
result=[forData,testing_data]