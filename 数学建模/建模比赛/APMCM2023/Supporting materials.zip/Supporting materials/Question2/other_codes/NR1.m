clc
clear

% Load the data from the '4Tables_total.xlsx' Excel file
data = xlsread('4Tables_total.xlsx');

% Extract the relevant data columns (2nd, 3rd, 4th, and 5th)
columns_to_forecast = data(:, 2:5);

refer_date = size(data, 1); % Number of rows, assuming each row corresponds to a year
step = 10; % Number of future periods to forecast

% Define different y-axis labels for each column
ytick_labels1 = {
    'Annual sales volume', 
    'Related patent applications quantity', 
    'Charging station quantity', 
    'Annual per capita GDP'
};

% Initialize a cell array to store forecasted data for each column
forecasted_data = cell(1, size(columns_to_forecast, 2));

% Loop through each column and perform forecasting
for col = 1:size(columns_to_forecast, 2)
    % Get the data for the current column
    column_data = columns_to_forecast(:, col)';
    
    % Polynomial regression for forecasting
    coefficients = polyfit(1:size(column_data, 2), column_data, 3); % You can adjust the polynomial degree as needed
    x = (refer_date + 1):(refer_date + step);
    for kk = 1:length(x)
        forData(kk) = polyval(coefficients, x(kk));
    end
    
    % Store the forecasted data in the cell array
    forecasted_data{col} = forData;
    
    % Plot the historical data and forecasted values for the current column
    figure
    plot(1:length(column_data), column_data)
    hold on
    plot((length(column_data) + 1):(length(column_data) + step), forecasted_data{col})
    xlabel('Year')
    ylabel(ytick_labels1{col}) % Set the y-axis label for the current column
    title(sprintf('Forecast for %s using Polynomial Regression', ytick_labels1{col}), 'FontSize', 0.9*get(gca,'FontSize'))
    legend('Historical Data', 'Forecasted Data', 'Location', 'southeast')
    grid on
    set(gcf,'Color',[1 1 1])
end
