clc
clear

% Load the data from the '4Tables_total.xlsx' Excel file
data = xlsread('4Tables_total.xlsx');

% Extract the relevant data columns (2nd, 3rd, 4th, and 5th)
columns_to_forecast = data(:, 2:5);

refer_date = size(data, 1); % Number of rows, assuming each row corresponds to a year
step = 10; % Number of future periods to forecast

% Define different y-axis labels for each column
ytick_labels1 = {
    'Annual sales volume', 
    'Related patent applications quantity', 
    'Charging station quantity', 
    'Annual per capita GDP'
};

% Initialize a cell array to store forecasted data for each column
forecasted_data = cell(1, size(columns_to_forecast, 2));

% Loop through each column and perform forecasting
for col = 1:size(columns_to_forecast, 2)
    % Get the data for the current column
    column_data = columns_to_forecast(:, col)';
    
    % Polynomial regression for forecasting
    coefficients = polyfit(1:size(column_data, 2), column_data, 3); % You can adjust the polynomial degree as needed
    x = (refer_date + 1):(refer_date + step);
    for kk = 1:length(x)
        forData(kk) = polyval(coefficients, x(kk));
    end
    
    % Store the forecasted data in the cell array
    forecasted_data{col} = forData;
    
    % Plot the historical data and forecasted values for the current column
    figure('Renderer', 'painters', 'Position', [100, 100, 800, 600], 'Color', 'white', 'InvertHardcopy', 'off', 'PaperPositionMode', 'auto', 'PaperUnits', 'points', 'PaperSize', [800, 600]);
    plot(1:length(column_data), column_data, 'LineWidth', 1)
    hold on
    plot((length(column_data) + 1):(length(column_data) + step), forecasted_data{col}, 'LineWidth', 1)
    xlabel('Year', 'FontWeight', 'bold', 'FontAngle', 'italic')
    ylabel(ytick_labels1{col}, 'FontWeight', 'bold', 'FontAngle', 'italic') % Set the y-axis label for the current column
    title(sprintf('Forecast for %s using Polynomial Regression', ytick_labels1{col}), 'FontWeight', 'bold', 'FontAngle', 'italic', 'FontSize', 1.1*get(gca,'FontSize'))
    legend('Historical Data', 'Forecasted Data', 'Location', 'southeast', 'FontWeight', 'bold', 'FontAngle', 'italic')
    grid on
    
    % Set custom x-axis labels
    xtick_positions = 1:3:(refer_date + step);
    xtick_labels = arrayfun(@(year) sprintf('%d', year), 2011:3:2032, 'UniformOutput', false);
    xticks(xtick_positions);
    xticklabels(xtick_labels);
    
    % Save the plot as a JPG file with specified settings
    save_path = 'E:\APCP\Question2\Result';
    file_name = sprintf('Forecast_%s.jpg', strrep(ytick_labels1{col}, ' ', '_'));
    full_path = fullfile(save_path, file_name);
    print(full_path, '-djpeg', '-r600');
    
    % Write the forecasted data to a separate table
    forecasted_table = [(refer_date + 1):(refer_date + step); forecasted_data{col}];
    writematrix(forecasted_table, sprintf('E:\\APCP\\Question2\\Result\\Forecast_%s.csv', strrep(ytick_labels1{col}, ' ', '_')));
end
