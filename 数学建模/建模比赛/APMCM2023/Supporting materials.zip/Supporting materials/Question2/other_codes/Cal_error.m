clc
clear
data = xlsread('4Tables_total.xlsx');
% Read data from an Excel file


% Extract data from columns 2 to 5 and perform ARIMA forecasts for each
for column = 2:2
    
    % Extract data column
    column_data = data(:, column);
    
    % Set the forecasting period
    step = 1;   
    
    % Call the ARIMA function for forecasting
    [forData] = ARIMA1(column_data, step);
end
 