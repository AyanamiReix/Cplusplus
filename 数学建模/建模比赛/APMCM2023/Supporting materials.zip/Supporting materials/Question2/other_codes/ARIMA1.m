function [forData]=ARIMA1(data,step)
ddata=data;
d=0;
while kpsstest(ddata)==1
    ddata = diff(data);
    d=d+1;
    if d>3
        break
    end
end
% 数据平稳性测试
% adftest(data)
% kpsstest(data)
% 
% % 一阶差分并平稳性检验
% ddata = diff(data);
% d1_adf = adftest(ddata);
% d1_kpss = kpsstest(ddata);


%% 计算pq取值
pmax = 3;
qmax = 3;
% d = 1;
[p q ]=findPQ(data,pmax,qmax,d);

%% 构建模型
% p = 3;q = 4;
Mdl = arima(p, d, q);  %第二个变量值为1，即一阶差分
EstMdl = estimate(Mdl,data);
%% 模型预测
% step = 10; %预测多少期
[forData,YMSE] = forecast(EstMdl,step,'Y0',data);
%matlab2018及以下版本写为Predict_Y(i+1) = forecast(EstMdl,1,'Y0',Y(1:i));
% lower = forData - 1.96*sqrt(YMSE); %95置信区间下限
% upper = forData + 1.96*sqrt(YMSE); %95置信区间上限
figure
plot(1:length(data),data)
hold on
plot((length(data)+1):length(data)+step,forData)
hold on
hXLabel = xlabel('Year');
hYLabel = ylabel('Number of patents applied for by new energy vehicle enterprises');
set(gcf,'Color',[1 1 1])
% plot((length(data)+1):length(data)+step,lower)
% plot((length(data)+1):length(data)+step,upper)
%% 计算p和q的函数
    function [p q] = findPQ(data,pmax,qmax,d)
        data = reshape(data,length(data),1);
        LOGL=zeros(pmax+1,qmax+1);
        PQ=zeros(pmax+1,qmax+1);
        for p=0:pmax
            for q=0:qmax
                model=arima(p,d,q);
                [fit,~,logL]=estimate(model,data);  %指定模型的结构
                LOGL(p+1,q+1)=logL;
                PQ(p+1,q+1)=p+q;  %计算拟合参数的个数
            end
        end
        LOGL=reshape(LOGL,(pmax+1)*(qmax+1),1);
        PQ=reshape(PQ,(pmax+1)*(qmax+1),1);
        m2 = length(data);
        [aic,bic]=aicbic(LOGL,PQ+1,m2);
        aic0 = reshape(aic,(pmax+1),(qmax+1));
        bic0= reshape(bic,(pmax+1),(qmax+1));
        
        aic1 = min(aic0(:));
        index = aic1==aic0;
        [pp qq] = meshgrid(0:pmax,0:qmax);
        p0 = pp(index);
        q0 = qq(index);
        
        aic2 = min(bic0(:));
        index = aic2==bic0;
        [pp qq] = meshgrid(0:pmax,0:qmax);
        p1 = pp(index);
        q1 = qq(index);
        
        if p0^2+q0^2> p1^2+q1^2
            p = p1;
            q = q1;
        else
            p = p0;
            q = q0;
        end
        
    end
end